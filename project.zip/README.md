# EvalBoard
- **Test suites.** Create cases by hand or import a CSV. Each case can have graders: `llm_judge` (another AI grades the meaning of the answer), `keywords`, `contains`, `exact_match`, `regex`, `json_valid`.
Planned: a CLI and CI gate, password reset and email verification, and an option to lock down sign-ups for public deployments.
